package com.svv;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Deserialization {

	public static void main(String[] args) {

		try {

			FileInputStream fin = new FileInputStream("Employee1.txt");
			ObjectInputStream oin = new ObjectInputStream(fin);
			Object emp = oin.readObject();
			oin.close();
			System.out.println("Employee " + emp);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
