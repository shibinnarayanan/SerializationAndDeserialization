package com.svv;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Serialization {
	
	public static void main(String[] args) {
		
		try {
			Employee empl = new Employee(101, "Shibin", 34);
			
			FileOutputStream fout = new FileOutputStream("Employee1.txt");
			ObjectOutputStream out = new ObjectOutputStream(fout);
			out.writeObject(empl);
			out.flush();
		    out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
